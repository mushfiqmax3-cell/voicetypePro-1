package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VoiceType Pro", appName)
    }

    @Test
    fun `state machine transitions follow exact specification`() {
        val machine = BubbleStateMachine()
        assertEquals(BubbleState.IDLE, machine.currentState)
        assertTrue(machine.isMicEnabled())

        // IDLE --(tap mic)--> RECORDING
        assertEquals(BubbleState.RECORDING, machine.onMicTapped())
        assertTrue(machine.isMicEnabled())

        // RECORDING --(tap ✕)--> IDLE
        assertEquals(BubbleState.IDLE, machine.onCancelToIdle())

        // IDLE --(tap mic)--> RECORDING --(tap mic)--> PROCESSING
        assertEquals(BubbleState.RECORDING, machine.onMicTapped())
        assertEquals(BubbleState.PROCESSING, machine.onMicTapped())
        assertFalse(machine.isMicEnabled())
        assertNull(machine.onMicTapped()) // Mic disabled during PROCESSING

        // PROCESSING --(success)--> INSERTED --> IDLE
        assertTrue(machine.onTranscriptionSuccess())
        assertEquals(BubbleState.INSERTED, machine.currentState)
        machine.resetToIdle()
        assertEquals(BubbleState.IDLE, machine.currentState)
    }

    @Test
    fun `text inserter splices at cursor with smart leading space`() {
        // Empty field
        val (emptyResult, emptyCursor) = TextInserter.buildInsertedText(
            existingText = "",
            selectionStart = 0,
            selectionEnd = 0,
            newText = "আমি ভালো আছি।"
        )
        assertEquals("আমি ভালো আছি।", emptyResult)
        assertEquals("আমি ভালো আছি।".length, emptyCursor)

        // Appending after non-space character adds a leading space
        val (appendResult, appendCursor) = TextInserter.buildInsertedText(
            existingText = "Hello",
            selectionStart = 5,
            selectionEnd = 5,
            newText = "world!"
        )
        assertEquals("Hello world!", appendResult)
        assertEquals(12, appendCursor)

        // Inserting in the middle of existing text
        val (midResult, midCursor) = TextInserter.buildInsertedText(
            existingText = "Good morning",
            selectionStart = 4,
            selectionEnd = 4,
            newText = "very"
        )
        assertEquals("Good very morning", midResult)
        assertEquals(9, midCursor)
    }
}
