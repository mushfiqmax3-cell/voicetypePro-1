package com.example

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TranscriptionResponse(
    val text: String,
    val modelUsed: String,
    val usedFallbackModel: Boolean
)

sealed class TranscriptionException(message: String) : Exception(message) {
    class NoInternet : TranscriptionException("No internet connection. Please check your network.")
    class InvalidApiKey : TranscriptionException("Invalid Gemini API key. Check your key in VoiceType Pro.")
    class QuotaExceeded : TranscriptionException("Quota exceeded (429). Please wait a moment and try again.")
    class EmptyResult : TranscriptionException("No speech detected.")
    class ApiError(msg: String) : TranscriptionException(msg)
}

/**
 * Handles inline base64 audio transcription with the Gemini API over OkHttp + Coroutines.
 */
object GeminiTranscriber {
    const val TRANSCRIPTION_PROMPT =
        "Transcribe this audio exactly as spoken. The speaker uses Bengali,\n" +
        "English, or a mix of both. Write Bengali words in Bengali script\n" +
        "(বাংলা হরফ) and English words in English letters. Do not translate.\n" +
        "Remove filler sounds (উম, আ, um, uh). Add natural punctuation\n" +
        "(। for Bengali sentences, . ? ! for English). Output ONLY the\n" +
        "transcribed text — no quotes, no labels, no explanations.\n" +
        "If there is no speech, output nothing."

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var activeCall: Call? = null

    /**
     * Cancels any in-flight OkHttp network request immediately.
     */
    fun cancelActiveRequest() {
        try {
            activeCall?.cancel()
        } catch (_: Exception) {
        } finally {
            activeCall = null
        }
    }

    /**
     * Sends the .m4a file inline (Base64) to Gemini and returns the trimmed transcription.
     * Always deletes [audioFile] in the finally block (success, failure, or cancellation).
     */
    suspend fun transcribeAudio(
        audioFile: File,
        apiKey: String,
        configuredModel: String
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }
            if (!audioFile.exists() || audioFile.length() == 0L) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            val audioBytes = audioFile.readBytes()
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val requestBodyJson = buildTranscriptionJson(base64Audio)

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = requestBodyJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                // Retry once with fallback model "gemini-2.5-flash"
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = requestBodyJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                val text = fallbackAttempt.extractedText.orEmpty().trim()
                if (text.isEmpty()) {
                    return@withContext Result.failure(TranscriptionException.EmptyResult())
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = text,
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            val text = primaryAttempt.extractedText.orEmpty().trim()
            if (text.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.EmptyResult())
            }

            Result.success(
                TranscriptionResponse(
                    text = text,
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            cancelActiveRequest()
            throw e
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Connection timed out. Please try again."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Transcription failed."))
        } finally {
            activeCall = null
            try {
                if (audioFile.exists()) {
                    audioFile.delete()
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Makes a tiny test request to validate the user's API key and model configuration.
     */
    suspend fun testApiKey(
        apiKey: String,
        configuredModel: String
    ): Result<TranscriptionResponse> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(TranscriptionException.InvalidApiKey())
            }

            val testJson = JSONObject().apply {
                val part = JSONObject().put("text", "Reply with OK")
                val parts = JSONArray().put(part)
                val content = JSONObject().put("parts", parts)
                put("contents", JSONArray().put(content))
                put("generationConfig", JSONObject().put("temperature", 0))
            }.toString()

            val primaryModel = configuredModel.trim().ifEmpty { Prefs.DEFAULT_MODEL_NAME }
            val primaryAttempt = executeGenerateContent(
                model = primaryModel,
                apiKey = cleanKey,
                bodyJson = testJson
            )

            if (primaryAttempt.isModelNotFound && primaryModel != Prefs.FALLBACK_MODEL_NAME) {
                val fallbackAttempt = executeGenerateContent(
                    model = Prefs.FALLBACK_MODEL_NAME,
                    apiKey = cleanKey,
                    bodyJson = testJson
                )
                if (fallbackAttempt.exception != null) {
                    return@withContext Result.failure(fallbackAttempt.exception)
                }
                return@withContext Result.success(
                    TranscriptionResponse(
                        text = fallbackAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                        modelUsed = Prefs.FALLBACK_MODEL_NAME,
                        usedFallbackModel = true
                    )
                )
            }

            if (primaryAttempt.exception != null) {
                return@withContext Result.failure(primaryAttempt.exception)
            }

            Result.success(
                TranscriptionResponse(
                    text = primaryAttempt.extractedText.orEmpty().trim().ifEmpty { "OK" },
                    modelUsed = primaryModel,
                    usedFallbackModel = false
                )
            )
        } catch (e: UnknownHostException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: SocketTimeoutException) {
            Result.failure(TranscriptionException.ApiError("Request timed out."))
        } catch (e: IOException) {
            Result.failure(TranscriptionException.NoInternet())
        } catch (e: Exception) {
            Result.failure(TranscriptionException.ApiError(e.localizedMessage ?: "Validation failed."))
        }
    }

    private fun buildTranscriptionJson(base64Audio: String): String {
        val inlineData = JSONObject().apply {
            put("mime_type", "audio/mp4")
            put("data", base64Audio)
        }
        val audioPart = JSONObject().apply {
            put("inline_data", inlineData)
        }
        val textPart = JSONObject().apply {
            put("text", TRANSCRIPTION_PROMPT)
        }
        val partsArray = JSONArray().apply {
            put(audioPart)
            put(textPart)
        }
        val contentObj = JSONObject().apply {
            put("parts", partsArray)
        }
        val contentsArray = JSONArray().apply {
            put(contentObj)
        }
        val generationConfig = JSONObject().apply {
            put("temperature", 0)
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", generationConfig)
        }.toString()
    }

    private data class RawApiAttempt(
        val extractedText: String? = null,
        val isModelNotFound: Boolean = false,
        val exception: TranscriptionException? = null
    )

    private suspend fun executeGenerateContent(
        model: String,
        apiKey: String,
        bodyJson: String
    ): RawApiAttempt {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("x-goog-api-key", apiKey)
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val call = okHttpClient.newCall(request)
        activeCall = call

        val (code, responseBody) = suspendCancellableCoroutine<Pair<Int, String>> { cont ->
            cont.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Exception) {
                }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (!cont.isCancelled) {
                        cont.resumeWithException(e)
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { resp ->
                        val bodyStr = resp.body?.string().orEmpty()
                        if (!cont.isCancelled) {
                            cont.resume(resp.code to bodyStr)
                        }
                    }
                }
            })
        }

        if (code == 404) {
            return RawApiAttempt(isModelNotFound = true)
        }

        if (code == 400 || code == 401 || code == 403) {
            val lower = responseBody.lowercase()
            if (lower.contains("api_key_invalid") ||
                lower.contains("api key not valid") ||
                lower.contains("invalid api key") ||
                code == 401 || code == 403
            ) {
                return RawApiAttempt(exception = TranscriptionException.InvalidApiKey())
            }
            if (lower.contains("not found") || lower.contains("is not found for api version")) {
                return RawApiAttempt(isModelNotFound = true)
            }
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Request error ($code)."
                )
            )
        }

        if (code == 429) {
            return RawApiAttempt(exception = TranscriptionException.QuotaExceeded())
        }

        if (code !in 200..299) {
            return RawApiAttempt(
                exception = TranscriptionException.ApiError(
                    parseErrorMessage(responseBody) ?: "Server error ($code)."
                )
            )
        }

        val extracted = extractCandidatesText(responseBody)
        return RawApiAttempt(extractedText = extracted)
    }

    fun extractCandidatesText(jsonString: String): String {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val firstCandidate = candidates.optJSONObject(0) ?: return ""
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val builder = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val text = part.optString("text", "")
                if (text.isNotEmpty()) {
                    builder.append(text)
                }
            }
            builder.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseErrorMessage(jsonString: String): String? {
        return try {
            val root = JSONObject(jsonString)
            val err = root.optJSONObject("error") ?: return null
            err.optString("message", "").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
