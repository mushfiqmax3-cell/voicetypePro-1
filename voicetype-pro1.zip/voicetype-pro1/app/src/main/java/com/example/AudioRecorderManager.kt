package com.example

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/**
 * Manages audio recording using MediaRecorder:
 * - AudioSource: VOICE_RECOGNITION (with fallback to MIC)
 * - Format: MPEG_4 / AAC
 * - Sampling rate: 16000 Hz, mono (1 channel), 64000 bps
 * - Saved as .m4a in cacheDir
 * - Max duration: 120 seconds (120,000 ms)
 */
class AudioRecorderManager(
    private val context: Context,
    private val onMaxDurationReached: () -> Unit
) {
    companion object {
        const val MAX_DURATION_MS = 120_000
        const val SAMPLE_RATE_HZ = 16_000
        const val BIT_RATE_BPS = 64_000
        const val CHANNELS_MONO = 1
    }

    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var isRecording = false

    @Synchronized
    fun startRecording(): Result<File> {
        stopAndReleaseInternal()
        val outputFile = File(
            context.cacheDir,
            "voicetype_rec_${System.currentTimeMillis()}.m4a"
        )
        currentOutputFile = outputFile

        return try {
            val recorder = createRecorderWithSource(outputFile, MediaRecorder.AudioSource.VOICE_RECOGNITION)
                ?: createRecorderWithSource(outputFile, MediaRecorder.AudioSource.MIC)
                ?: throw IllegalStateException("Unable to initialize MediaRecorder microphone source.")

            recorder.start()
            mediaRecorder = recorder
            isRecording = true
            Result.success(outputFile)
        } catch (e: Exception) {
            stopAndReleaseInternal()
            deleteFileSafely(outputFile)
            currentOutputFile = null
            Result.failure(e)
        }
    }

    private fun createRecorderWithSource(outputFile: File, audioSource: Int): MediaRecorder? {
        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        return try {
            recorder.setAudioSource(audioSource)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioSamplingRate(SAMPLE_RATE_HZ)
            recorder.setAudioChannels(CHANNELS_MONO)
            recorder.setAudioEncodingBitRate(BIT_RATE_BPS)
            recorder.setMaxDuration(MAX_DURATION_MS)
            recorder.setOutputFile(outputFile.absolutePath)
            recorder.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                    onMaxDurationReached()
                }
            }
            recorder.prepare()
            recorder
        } catch (e: Exception) {
            try {
                recorder.reset()
                recorder.release()
            } catch (_: Exception) {
            }
            null
        }
    }

    /**
     * Stops recording normally and returns the recorded .m4a file for transcription.
     */
    @Synchronized
    fun stopRecording(): File? {
        val file = currentOutputFile
        if (!isRecording) {
            stopAndReleaseInternal()
            return null
        }
        return try {
            mediaRecorder?.stop()
            stopAndReleaseInternal()
            if (file != null && file.exists() && file.length() > 0L) {
                file
            } else {
                deleteFileSafely(file)
                null
            }
        } catch (e: Exception) {
            stopAndReleaseInternal()
            deleteFileSafely(file)
            null
        }
    }

    /**
     * Stops recording immediately and deletes the recorded audio file (used when ✕ is tapped).
     */
    @Synchronized
    fun cancelAndDeleteRecording() {
        val file = currentOutputFile
        try {
            if (isRecording) {
                mediaRecorder?.stop()
            }
        } catch (_: Exception) {
        } finally {
            stopAndReleaseInternal()
            deleteFileSafely(file)
            currentOutputFile = null
        }
    }

    private fun stopAndReleaseInternal() {
        isRecording = false
        try {
            mediaRecorder?.reset()
        } catch (_: Exception) {
        }
        try {
            mediaRecorder?.release()
        } catch (_: Exception) {
        }
        mediaRecorder = null
    }

    fun deleteFileSafely(file: File?) {
        try {
            if (file != null && file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }
}
