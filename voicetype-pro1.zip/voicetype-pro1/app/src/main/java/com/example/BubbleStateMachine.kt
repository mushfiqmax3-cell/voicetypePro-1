package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Exact state machine for VoiceType Pro floating bubble:
 *
 * IDLE --(tap mic)--> RECORDING
 * RECORDING --(tap mic)--> PROCESSING
 * RECORDING --(tap ✕)--> IDLE (audio discarded)
 * PROCESSING --(success)--> INSERTED (✓) --> IDLE
 * PROCESSING --(tap ✕)--> IDLE (request cancelled)
 * PROCESSING --(error)--> IDLE (show error toast)
 */
enum class BubbleState {
    IDLE,
    RECORDING,
    PROCESSING,
    INSERTED
}

class BubbleStateMachine {
    private val _state = MutableStateFlow(BubbleState.IDLE)
    val state: StateFlow<BubbleState> = _state.asStateFlow()

    val currentState: BubbleState
        get() = _state.value

    /**
     * Handles a tap on the [ 🎙️ MIC ] button.
     * Note: Mic button is disabled during PROCESSING and INSERTED.
     *
     * @return The new state if a transition occurred, or null if ignored.
     */
    @Synchronized
    fun onMicTapped(): BubbleState? {
        return when (_state.value) {
            BubbleState.IDLE -> {
                _state.value = BubbleState.RECORDING
                BubbleState.RECORDING
            }
            BubbleState.RECORDING -> {
                _state.value = BubbleState.PROCESSING
                BubbleState.PROCESSING
            }
            BubbleState.PROCESSING,
            BubbleState.INSERTED -> null
        }
    }

    /**
     * Handles a tap on the [ ✕ CROSS ] button during RECORDING or PROCESSING.
     * Transitions directly to IDLE.
     */
    @Synchronized
    fun onCancelToIdle(): BubbleState {
        _state.value = BubbleState.IDLE
        return BubbleState.IDLE
    }

    /**
     * Transitions from PROCESSING to INSERTED (green ✓ shown for 1 second).
     */
    @Synchronized
    fun onTranscriptionSuccess(): Boolean {
        if (_state.value == BubbleState.PROCESSING) {
            _state.value = BubbleState.INSERTED
            return true
        }
        return false
    }

    /**
     * Transitions from INSERTED back to IDLE after 1 second, or from PROCESSING to IDLE on error.
     */
    @Synchronized
    fun resetToIdle() {
        _state.value = BubbleState.IDLE
    }

    /**
     * Returns true if the Mic button should be enabled for user clicks.
     */
    fun isMicEnabled(): Boolean {
        return _state.value == BubbleState.IDLE || _state.value == BubbleState.RECORDING
    }
}
