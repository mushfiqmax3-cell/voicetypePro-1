package com.example

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.hypot

/**
 * Foreground Service (foregroundServiceType="microphone") that displays the focus-preserving
 * floating bubble overlay on top of all applications and coordinates recording, Gemini
 * transcription, cursor insertion, and 30-second undo.
 */
class FloatingBubbleService : Service() {

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "voicetype_floating_mic_channel"
        private const val NOTIFICATION_ID = 4091
        private const val DRAG_THRESHOLD_PX = 10f
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_FLOATING_SERVICE"

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java)
            context.stopService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val stateMachine = BubbleStateMachine()

    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var audioRecorder: AudioRecorderManager

    private var overlayView: View? = null
    private var collapsedBubble: FrameLayout? = null
    private var expandedPill: LinearLayout? = null
    private var btnPillHandle: FrameLayout? = null
    private var btnMic: LinearLayout? = null
    private var imgMicState: ImageView? = null
    private var progressMic: ProgressBar? = null
    private var txtMicLabel: TextView? = null
    private var btnCross: FrameLayout? = null

    private var isExpanded = false
    private var timerJob: Job? = null
    private var transcriptionJob: Job? = null
    private var pulseAnimator: ObjectAnimator? = null
    private var elapsedSeconds = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audioRecorder = AudioRecorderManager(
            context = this,
            onMaxDurationReached = {
                serviceScope.launch {
                    if (stateMachine.currentState == BubbleState.RECORDING) {
                        Toast.makeText(
                            this@FloatingBubbleService,
                            "Max 120s reached — transcribing…",
                            Toast.LENGTH_SHORT
                        ).show()
                        handleMicToggleTap()
                    }
                }
            }
        )
        startForegroundWithMicrophoneType()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Display over other apps permission is required.",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
            return
        }

        setupFloatingOverlay()
        _isRunningFlow.value = true

        serviceScope.launch {
            stateMachine.state.collect { state ->
                renderBubbleState(state)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundWithMicrophoneType() {
        createNotificationChannel()
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic_white)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                R.drawable.ic_close_white,
                getString(R.string.stop_floating_mic),
                pendingStop
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_text)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun setupFloatingOverlay() {
        val inflater = LayoutInflater.from(this)
        val rootView = inflater.inflate(R.layout.floating_bubble, null)
        overlayView = rootView

        collapsedBubble = rootView.findViewById(R.id.collapsed_bubble)
        expandedPill = rootView.findViewById(R.id.expanded_pill)
        btnPillHandle = rootView.findViewById(R.id.btn_pill_handle)
        btnMic = rootView.findViewById(R.id.btn_mic)
        imgMicState = rootView.findViewById(R.id.img_mic_state)
        progressMic = rootView.findViewById(R.id.progress_mic)
        txtMicLabel = rootView.findViewById(R.id.txt_mic_label)
        btnCross = rootView.findViewById(R.id.btn_cross)

        val (savedX, savedY) = Prefs.getBubblePosition(this, defaultX = 0, defaultY = 280)

        // CRITICAL: FLAG_NOT_FOCUSABLE and FLAG_NOT_TOUCH_MODAL ensure the overlay NEVER steals
        // keyboard focus from the text field selected in another app.
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        // Attach drag vs. tap listener to collapsed bubble and expanded pill handle
        val dragOrTapBubbleListener = createDragOrTapTouchListener {
            toggleExpandedPill()
        }
        collapsedBubble?.setOnTouchListener(dragOrTapBubbleListener)
        btnPillHandle?.setOnTouchListener(dragOrTapBubbleListener)

        // [ 🎙️ MIC ] button tap (also supports dragging if user drags > 10px)
        btnMic?.setOnTouchListener(
            createDragOrTapTouchListener {
                handleMicToggleTap()
            }
        )

        // [ ✕ CROSS ] button: short tap cancels/undoes; long-press closes service
        btnCross?.setOnClickListener {
            handleCrossTap()
        }
        btnCross?.setOnLongClickListener {
            vibrateShort()
            Toast.makeText(this, "VoiceType Pro floating mic closed", Toast.LENGTH_SHORT).show()
            stopSelf()
            true
        }

        windowManager.addView(rootView, layoutParams)
    }

    /**
     * Distinguishes drag vs. tap:
     * - Movement > 10px = drag; on release after drag, snaps to nearest horizontal screen edge
     *   and saves the last position.
     * - Movement <= 10px = tap; executes [onTap].
     */
    private fun createDragOrTapTouchListener(onTap: () -> Unit): View.OnTouchListener {
        return object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (!isDragging && hypot(dx, dy) > DRAG_THRESHOLD_PX) {
                            isDragging = true
                        }
                        if (isDragging) {
                            val screenHeight = resources.displayMetrics.heightPixels
                            val maxY = (screenHeight - (overlayView?.height ?: 160)).coerceAtLeast(0)
                            layoutParams.x = (initialX + dx.toInt())
                            layoutParams.y = (initialY + dy.toInt()).coerceIn(48, maxY)
                            updateOverlayViewLayout()
                        }
                        return true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (isDragging) {
                            snapToNearestScreenEdge()
                        } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                            v.performClick()
                            onTap()
                        }
                        return true
                    }
                }
                return false
            }
        }
    }

    private fun snapToNearestScreenEdge() {
        val root = overlayView ?: return
        val screenWidth = resources.displayMetrics.widthPixels
        val viewWidth = root.width.takeIf { it > 0 } ?: dpToPx(56)
        val currentCenterX = layoutParams.x + viewWidth / 2
        val targetX = if (currentCenterX < screenWidth / 2) {
            dpToPx(8)
        } else {
            (screenWidth - viewWidth - dpToPx(8)).coerceAtLeast(0)
        }

        val startX = layoutParams.x
        ValueAnimator.ofInt(startX, targetX).apply {
            duration = 200L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                layoutParams.x = animator.animatedValue as Int
                updateOverlayViewLayout()
            }
            start()
        }
        Prefs.saveBubblePosition(this, targetX, layoutParams.y)
    }

    private fun toggleExpandedPill() {
        isExpanded = !isExpanded
        if (isExpanded) {
            collapsedBubble?.visibility = View.GONE
            expandedPill?.visibility = View.VISIBLE
        } else {
            expandedPill?.visibility = View.GONE
            collapsedBubble?.visibility = View.VISIBLE
        }
        overlayView?.post {
            keepOverlayInsideScreenBounds()
        }
    }

    private fun keepOverlayInsideScreenBounds() {
        val root = overlayView ?: return
        val screenWidth = resources.displayMetrics.widthPixels
        val viewWidth = root.width
        if (layoutParams.x + viewWidth > screenWidth - dpToPx(8)) {
            layoutParams.x = (screenWidth - viewWidth - dpToPx(8)).coerceAtLeast(dpToPx(8))
            updateOverlayViewLayout()
        }
    }

    /**
     * Handles tap on [ 🎙️ MIC ] according to the state machine:
     * - IDLE -> RECORDING: start MediaRecorder, vibrate, start pulsing red + 00:00 timer
     * - RECORDING -> PROCESSING: stop MediaRecorder, vibrate, send audio to Gemini
     * - PROCESSING / INSERTED: disabled
     */
    private fun handleMicToggleTap() {
        if (!stateMachine.isMicEnabled()) return

        when (val nextState = stateMachine.onMicTapped()) {
            BubbleState.RECORDING -> {
                vibrateShort()
                val startResult = audioRecorder.startRecording()
                if (startResult.isFailure) {
                    stateMachine.resetToIdle()
                    Toast.makeText(
                        this,
                        "Could not start microphone: ${startResult.exceptionOrNull()?.localizedMessage ?: "Error"}",
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }
                startRecordingTimer()
            }

            BubbleState.PROCESSING -> {
                vibrateShort()
                stopRecordingTimer()
                val recordedFile = audioRecorder.stopRecording()
                if (recordedFile == null) {
                    stateMachine.resetToIdle()
                    Toast.makeText(this, "Audio too short or empty.", Toast.LENGTH_SHORT).show()
                    return
                }
                startTranscription(recordedFile)
            }

            else -> Unit
        }
    }

    /**
     * Handles tap on [ ✕ CROSS ] according to the current state:
     * - While RECORDING -> stop recording, delete audio file, send nothing, return to IDLE, show "Cancelled" toast.
     * - While PROCESSING -> cancel coroutine and OkHttp call, discard result, return to IDLE.
     * - While IDLE -> if last transcription was inserted < 30s ago, UNDO it; otherwise collapse pill to bubble.
     */
    private fun handleCrossTap() {
        when (stateMachine.currentState) {
            BubbleState.RECORDING -> {
                stopRecordingTimer()
                audioRecorder.cancelAndDeleteRecording()
                stateMachine.onCancelToIdle()
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            }

            BubbleState.PROCESSING -> {
                GeminiTranscriber.cancelActiveRequest()
                transcriptionJob?.cancel()
                transcriptionJob = null
                stateMachine.onCancelToIdle()
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            }

            BubbleState.IDLE, BubbleState.INSERTED -> {
                if (TextInserter.canUndo()) {
                    val undone = VoiceTypeAccessibilityService.performUndoIfAvailable(this)
                    if (undone) {
                        vibrateShort()
                        Toast.makeText(this, "Undid last transcription", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(
                            this,
                            "Focus the text box to undo, or undo expired",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    // Collapse back to the small bubble when idle and no undo is pending
                    if (isExpanded) {
                        toggleExpandedPill()
                    }
                }
            }
        }
    }

    private fun startRecordingTimer() {
        elapsedSeconds = 0
        updateTimerLabel(0)
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive && stateMachine.currentState == BubbleState.RECORDING) {
                delay(1_000L)
                elapsedSeconds += 1
                updateTimerLabel(elapsedSeconds)
                if (elapsedSeconds >= 120) {
                    handleMicToggleTap()
                    break
                }
            }
        }
    }

    private fun stopRecordingTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    private fun updateTimerLabel(seconds: Int) {
        val mins = seconds / 60
        val secs = seconds % 60
        txtMicLabel?.text = String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    private fun startTranscription(audioFile: File) {
        val apiKey = Prefs.getApiKey(this)
        val configuredModel = Prefs.getModelName(this)

        transcriptionJob?.cancel()
        transcriptionJob = serviceScope.launch {
            try {
                val result = GeminiTranscriber.transcribeAudio(
                    audioFile = audioFile,
                    apiKey = apiKey,
                    configuredModel = configuredModel
                )
                result.fold(
                    onSuccess = { response ->
                        if (response.usedFallbackModel) {
                            Toast.makeText(
                                this@FloatingBubbleService,
                                "Model '$configuredModel' not found (404). Retried with '${Prefs.FALLBACK_MODEL_NAME}'. Consider updating Model Name in Settings.",
                                Toast.LENGTH_LONG
                            ).show()
                        }

                        Prefs.addHistoryItem(
                            context = this@FloatingBubbleService,
                            text = response.text,
                            modelUsed = response.modelUsed
                        )

                        val outcome = VoiceTypeAccessibilityService.insertTranscribedText(
                            context = this@FloatingBubbleService,
                            text = response.text
                        )
                        if (outcome == InsertionOutcome.COPIED_ONLY_MANUAL_PASTE) {
                            Toast.makeText(
                                this@FloatingBubbleService,
                                "Copied — long-press the text box and Paste",
                                Toast.LENGTH_LONG
                            ).show()
                        }

                        if (stateMachine.onTranscriptionSuccess()) {
                            delay(1_000L)
                            stateMachine.resetToIdle()
                        } else {
                            stateMachine.resetToIdle()
                        }
                    },
                    onFailure = { error ->
                        stateMachine.resetToIdle()
                        Toast.makeText(
                            this@FloatingBubbleService,
                            error.localizedMessage ?: "Transcription error",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                )
            } catch (_: CancellationException) {
                audioRecorder.deleteFileSafely(audioFile)
                stateMachine.resetToIdle()
            } catch (e: Exception) {
                audioRecorder.deleteFileSafely(audioFile)
                stateMachine.resetToIdle()
                Toast.makeText(
                    this@FloatingBubbleService,
                    e.localizedMessage ?: "Unexpected error",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun renderBubbleState(state: BubbleState) {
        val micButton = btnMic ?: return
        val micIcon = imgMicState ?: return
        val spinner = progressMic ?: return
        val label = txtMicLabel ?: return

        stopPulseAnimation()

        when (state) {
            BubbleState.IDLE -> {
                micButton.isEnabled = true
                micButton.background = getDrawable(R.drawable.bg_btn_mic_idle)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_mic_white)
                spinner.visibility = View.GONE
                label.text = "MIC"
                collapsedBubble?.background = getDrawable(R.drawable.bg_bubble_circle)
            }

            BubbleState.RECORDING -> {
                micButton.isEnabled = true
                micButton.background = getDrawable(R.drawable.bg_btn_mic_recording)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_mic_white)
                spinner.visibility = View.GONE
                updateTimerLabel(elapsedSeconds)
                startPulseAnimation(micButton)
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_recording)
            }

            BubbleState.PROCESSING -> {
                // Mic button must be disabled during PROCESSING
                micButton.isEnabled = false
                micButton.background = getDrawable(R.drawable.bg_btn_mic_processing)
                micIcon.visibility = View.GONE
                spinner.visibility = View.VISIBLE
                label.text = "WAIT…"
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_processing)
            }

            BubbleState.INSERTED -> {
                micButton.isEnabled = false
                micButton.background = getDrawable(R.drawable.bg_btn_mic_inserted)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_check_white)
                spinner.visibility = View.GONE
                label.text = "✓"
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_inserted)
            }
        }
    }

    private fun startPulseAnimation(target: View) {
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1.0f, 1.06f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.0f, 1.06f)
        val alpha = PropertyValuesHolder.ofFloat(View.ALPHA, 1.0f, 0.82f)
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(target, scaleX, scaleY, alpha).apply {
            duration = 550L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        btnMic?.apply {
            scaleX = 1.0f
            scaleY = 1.0f
            alpha = 1.0f
        }
    }

    private fun vibrateShort() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(45L, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(45L)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun updateOverlayViewLayout() {
        val view = overlayView ?: return
        try {
            windowManager.updateViewLayout(view, layoutParams)
        } catch (_: Exception) {
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    override fun onDestroy() {
        _isRunningFlow.value = false
        stopRecordingTimer()
        stopPulseAnimation()
        GeminiTranscriber.cancelActiveRequest()
        transcriptionJob?.cancel()
        audioRecorder.cancelAndDeleteRecording()
        serviceScope.cancel()

        overlayView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        super.onDestroy()
    }
}
