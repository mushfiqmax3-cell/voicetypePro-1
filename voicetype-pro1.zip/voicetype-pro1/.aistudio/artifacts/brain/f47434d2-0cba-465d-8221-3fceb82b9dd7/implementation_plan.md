# VoiceType Pro

VoiceType Pro is a native Android personal voice-typing utility that keeps a non-intrusive floating microphone bubble on top of all applications, transcribing spoken Bengali, English, or mixed speech via the Gemini API and automatically typing the result into any currently focused text box across the system.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product and technical decisions have been confirmed based on your preferences:

- **Confirmed Decision 1 — Gemini Model Configuration & Auto-Fallback**: Default model is configured as `gemini-3.5-transcribe` in settings. If the Gemini endpoint returns HTTP 404 (model not found), the transcriber automatically retries once with `gemini-2.5-flash` and shows an informative toast prompting the user to update the model in Settings.
- **Confirmed Decision 2 — API Key Provisioning & Encrypted Storage**: Secrets are configured via `BuildConfig` (`.env.example`) for safe platform injection and automatically pre-seeded into `EncryptedSharedPreferences` (`androidx.security:security-crypto`) on initial launch. Users can view (masked with show/hide toggle), edit, and validate the key using the **Save & Test** button, and should also configure their key in the **Secrets panel in AI Studio**.
- **Confirmed Decision 3 — Floating Overlay Aesthetic**: The floating overlay uses a **Compact Glassmorphic Dark Pill** aesthetic (`#E612161F` with subtle border highlight `#33FFFFFF`) and high-contrast status indicators (Crimson Red `#FF3B5C` with pulsing ring for recording, Amber/Cyan spinner for processing, and Emerald Green `#10B981` `✓` on insertion).

---

## 1. Overview & Core Concept

- **What It Does**: Provides a persistent, focus-preserving floating chat-head style bubble (`TYPE_APPLICATION_OVERLAY` with `FLAG_NOT_FOCUSABLE` and `FLAG_NOT_TOUCH_MODAL`) running inside a microphone foreground service. Users can tap the bubble to expand a compact two-button control pill (`[ 🎙️ MIC ]` and `[ ✕ CROSS ]`), toggle voice recording in Bengali, English, or mixed speech, and have the punctuated transcription automatically inserted at their active cursor position in any app (WhatsApp, Messenger, Chrome, Gmail, Notepad, Telegram, Facebook).
- **Target Audience / Persona**: Bilingual Bengali + English speakers who want fast, accurate, hands-free dictation across all Android messaging, browser, and productivity apps without switching keyboards or losing focus on their active text input.
- **Key Value**: Preserves active keyboard/cursor focus in external apps while delivering natural Bengali (`বাংলা হরফ`) and English mixed transcription with filler-word removal, smart punctuation (`।`, `.`, `?`, `!`), instant 30-second undo, and resilient clipboard/paste fallbacks.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Onboarding & Permission Readiness (Main Screen)**:
   - User opens **VoiceType Pro** and sees bilingual English + Bengali (`বাংলা`) headers and subtitles.
   - User verifies the live permission checklist (auto-refreshed on `onResume`):
     - Microphone (`RECORD_AUDIO`)
     - Display over other apps (`SYSTEM_ALERT_WINDOW` -> opens `ACTION_MANAGE_OVERLAY_PERMISSION`)
     - Accessibility Service (`VoiceTypeAccessibilityService` -> opens `ACTION_ACCESSIBILITY_SETTINGS` with clear step-by-step instructions)
     - Notifications (`POST_NOTIFICATIONS` on Android 13+)
   - User verifies or tests their Gemini API key via **Save & Test** (which executes a minimal validation request against the configured model) and confirms the model name (`gemini-3.5-transcribe`).
   - Once all required permissions are granted and an API key is saved, the primary **"Start Floating Mic / ফ্লোটিং মাইক চালু করুন"** button enables.
2. **Floating Bubble & Pill Interaction**:
   - Tapping **Start Floating Mic** launches the foreground service with a persistent notification and displays a `56dp` circular floating bubble.
   - **Drag vs. Tap**: Dragging (> 10px movement) moves the bubble smoothly across the screen; releasing snaps it smoothly to the nearest horizontal screen edge and saves its coordinates. Tapping (< 10px movement) expands the bubble into the horizontal glassmorphic pill showing `[ 🎙️ MIC ]` and `[ ✕ CROSS ]`. Tapping the bubble handle again collapses it back to the `56dp` circle.
3. **Toggle Recording, Cancel, & Undo**:
   - **1st Tap on `🎙️ MIC`**: Vibrates briefly, transitions `IDLE -> RECORDING`, turns the mic button vibrant red with a pulsing ring animation, and starts a live `00:00` timer (auto-stops at `02:00` / 120 seconds).
   - **2nd Tap on `🎙️ MIC`**: Vibrates briefly, stops recording, transitions `RECORDING -> PROCESSING`, disables the mic button, and displays an indeterminate loading spinner while sending inline Base64 `.m4a` audio to Gemini.
   - **Insertion & Completion**: Once transcribed, `VoiceTypeAccessibilityService` inserts the text at the active cursor in the target app. The pill transitions `PROCESSING -> INSERTED`, displays a green `✓` for 1 second, records the entry in the 20-item History list, and returns to `IDLE`.
   - **Context-Aware `✕ CROSS` Button**:
     - During `RECORDING`: Stops recording, deletes the `.m4a` cache file, shows a `"Cancelled"` toast, and returns to `IDLE`.
     - During `PROCESSING`: Cancels the active coroutine and OkHttp call, deletes the audio file, discards any response, and returns to `IDLE`.
     - During `IDLE` (within 30s of last insertion): Performs **UNDO**, restoring the target text field's exact previous text prior to the last insertion.
     - **Long-press `✕ CROSS`**: Stops the foreground service and hides the floating bubble.

### Visual Identity & Theme
- **Aesthetic Direction**: Utilitarian Precision meets Glassmorphic Tactility—clean, high-contrast bilingual dashboard in Jetpack Compose paired with a sleek, zero-distraction dark glassmorphic overlay pill.
- **Color Palette & Mood**:
  - **Primary / Accent**: Deep Electric Indigo (`#4F46E5` light / `#818CF8` dark) with Teal/Cyan secondary accents (`#06B6D4`).
  - **Semantic Status Colors**: Recording Crimson (`#FF3B5C`), Processing Amber (`#F59E0B`), Insertion Emerald (`#10B981`), Error Rose (`#EF4444`).
  - **Floating Overlay Surface**: Translucent Obsidian (`#E612161F`) with `1dp` specular border (`#33FFFFFF`) so it remains legible over both light and dark host apps.
- **Typography & Hierarchy**:
  - **Main Compose UI**: Clean geometric sans-serif headings paired with legible body text and monospace numerals for timers and API key masking, with crisp rendering for Bengali script (`বাংলা হরফ`) subtitles alongside English labels.
- **Component Styling & Layout**:
  - Material 3 cards with subtle tonal elevation for the API Configuration card, Live Permission Checklist card, Floating Service Control banner, and Recent Transcriptions History list (up to 20 items, each with timestamp and one-tap Copy icon button).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Focus-Preserving Native View Overlay vs. Compose Overlay**
  - *Chosen Approach*: Use Android XML/View (`WindowManager` + `res/layout/floating_bubble.xml`) with `TYPE_APPLICATION_OVERLAY` and `FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCH_MODAL` for the floating bubble, while using Jetpack Compose (Material 3) for the main configuration & history screen.
  - *Why*: `WindowManager` overlays with `FLAG_NOT_FOCUSABLE` guarantee that tapping `[ 🎙️ MIC ]` or `[ ✕ CROSS ]` never steals input focus or dismisses the soft keyboard in WhatsApp, Chrome, or Messenger.
- **Decision 2: Cursor-Aware Accessibility Insertion with Two-Tier Clipboard Fallback**
  - *Chosen Approach*: `TextInserter` inspects `rootInActiveWindow.findFocus(FOCUS_INPUT)` (and falls back to iterating `getWindows()` excluding our own package overlay) to read existing text, hint state (`isShowingHintText`), and cursor selection (`textSelectionStart`/`End`). It splices the new text with smart leading-space detection, applies `ACTION_SET_TEXT`, and advances the cursor via `ACTION_SET_SELECTION`. If `ACTION_SET_TEXT` fails or no node is accessible, it copies to `ClipboardManager` and triggers `ACTION_PASTE`, or notifies the user with `"Copied — long-press the text box and Paste"`.
  - *Why*: Custom webviews or canvas-rendered inputs in some apps reject `ACTION_SET_TEXT` but accept `ACTION_PASTE` or manual paste.
- **Decision 3: Encrypted Preferences with BuildConfig Pre-Seeding**
  - *Chosen Approach*: Store the API key in `EncryptedSharedPreferences` (`Prefs`), pre-populated on first launch from `BuildConfig.GEMINI_API_KEY` if no user-edited key is saved yet, while storing model name, bubble coordinates, and the 20-item JSON history list for immediate access by both the Activity and Foreground Service.
  - *Why*: Protects credentials at rest while giving the user full inspection, testing (`Save & Test`), and override control in the UI.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                        MainActivity (Jetpack Compose)                     │
│  ┌─────────────────────┐  ┌──────────────────────┐  ┌──────────────────┐  │
│  │ API Key & Model UI  │  │ Permission Checklist │  │ 20-Item History  │  │
│  │  (Save & Test API)  │  │ (Live onResume Sync) │  │  (Copy to Clip)  │  │
│  └─────────┬───────────┘  └──────────┬───────────┘  └────────┬─────────┘  │
└────────────┼─────────────────────────┼───────────────────────┼────────────┘
             │                         │                       │
             ▼                         ▼                       ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                 Prefs (EncryptedSharedPreferences + StateFlow)            │
│    • API Key (AES256-GCM)   • Model Name ("gemini-3.5-transcribe")        │
│    • Last Bubble X/Y Edge   • Last 20 Transcriptions History              │
└────────────┬─────────────────────────────────────────────────┬────────────┘
             │                                                 ▲
             ▼                                                 │
┌──────────────────────────────────────────────────────────────┴────────────┐
│          FloatingBubbleService (ForegroundService: microphone)            │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │ WindowManager Overlay (res/layout/floating_bubble.xml)              │  │
│  │ • Collapsed 56dp Bubble (Drag >10px + Edge Snap / Tap <10px Expand) │  │
│  │ • Expanded Pill: [ 🎙️ MIC (Timer/Spinner/✓) ]  [ ✕ CROSS (Undo) ]   │  │
│  └───────────────┬─────────────────────────────────────┬───────────────┘  │
│                  │                                     │                  │
│                  ▼                                     ▼                  │
│  ┌───────────────────────────────┐     ┌───────────────────────────────┐  │
│  │     BubbleStateMachine        │     │     AudioRecorderManager      │  │
│  │ IDLE ⇄ RECORDING → PROCESSING │     │ MediaRecorder (AAC, 16kHz,    │  │
│  │      → INSERTED (✓ 1s) → IDLE │     │ 64kbps, mono .m4a, max 120s)  │  │
│  └───────────────┬───────────────┘     └───────────────┬───────────────┘  │
└──────────────────┼─────────────────────────────────────┼──────────────────┘
                   │                                     │
                   ▼                                     ▼
┌──────────────────────────────────────┐ ┌──────────────────────────────────┐
│          GeminiTranscriber           │ │  VoiceTypeAccessibilityService   │
│ • OkHttp (15s connect / 60s read)    │ │ • Tracks focused editable node   │
│ • Inline Base64 audio/mp4 payload    │ │ • TextInserter: cursor splice,   │
│ • Auto-retry 404 → gemini-2.5-flash  │ │   ACTION_SET_TEXT, ACTION_PASTE  │
│ • Always deletes .m4a in finally     │ │ • 30-second Undo snapshot state  │
└──────────────────────────────────────┘ └──────────────────────────────────┘
```

### Data Model & State
- **`BubbleState` (`BubbleStateMachine`)**:
  - `IDLE`: Ready to record; `✕` triggers 30s Undo if available, or collapses/closes on long-press.
  - `RECORDING(elapsedSeconds: Int)`: Mic pulsing red, live `MM:SS` timer up to 120s; tap Mic transitions to `PROCESSING`; tap `✕` stops and deletes audio immediately.
  - `PROCESSING`: Mic disabled with loading spinner; tap `✕` cancels active `Job` + `OkHttp` `Call`.
  - `INSERTED`: Displays green `✓` badge for 1,000ms before returning to `IDLE`.
- **`UndoSnapshot` (`TextInserter`)**:
  - Holds `previousText: String`, `insertedText: String`, `timestampMs: Long`, and node reference metadata so tapping `✕` while `IDLE` within 30,000ms restores `previousText`.
- **`TranscriptionItem` (`Prefs`)**:
  - Holds `id: Long`, `text: String`, `timestamp: Long`, and `modelUsed: String`, capped at the 20 most recent items.

### Interactive Component & State Mapping
- **API Key Save & Test Flow**: Validates non-empty key, saves to `EncryptedSharedPreferences`, and triggers `GeminiTranscriber.testApiKey(apiKey, model)` with a minimal prompt (`"Say OK"`). If `gemini-3.5-transcribe` returns 404 during test or transcription, it automatically retries with `gemini-2.5-flash` and alerts the user via Toast.
- **Drag & Edge-Snap Physics**: `OnTouchListener` records `initialX`, `initialY`, `initialTouchX`, `initialTouchY`. Movement exceeding `10px` enters drag mode; `ACTION_UP` animates `WindowManager.LayoutParams.x` to `0` or `screenWidth - bubbleWidth` and persists `(x, y)` in `Prefs`.
- **Hardware Vibration & Cleanup**: `FloatingBubbleService` triggers a crisp haptic pulse (`VibrationEffect.createOneShot(40, DEFAULT_AMPLITUDE)`) on recording start and stop, and guarantees deletion of temporary `.m4a` files in `cacheDir` across success, error, and cancellation paths.
